package Practice;



public class Student implements Comparable<Student>{

	private String name;
	private int age;
	private int rollno;
	
	public Student(String name,int age,int rollno){
		
		this.name=name;
		this.age=age;
		this.rollno=rollno;
		
	}
	
	public String getName(){
		return name;
	}
	public void setName(String name){
		this.name=name;
	}
	
	public int getAge(){
		return age;
	}
	public void setAge(int age){
		this.age=age;
	}
	
	public int getRollno(){
		return rollno;
	}
	public void setRollno(int rollno){
		this.rollno=rollno;
	}

	
	
	/*public int compareTo(Student compare) {
		// TODO Auto-generated method stub
		int compareage = ((Student)compare).getAge();
		return this.age-compareage;
	}*/
	@Override
	public String toString(){
		return "[Name: "+ name+", Age: "+age+", Roll No: "+rollno+"]";
		
	}

	@Override
	public int compareTo(Student st) {
		// TODO Auto-generated method stub
		if(age==st.age)  
			return 0;  
			else if(age>st.age)  
			return 1;  
			else  
			return -1;  
			}  
	}

	


package Practice;
import java.util.*;
public class ArraylistStuAgeSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Student> l = new ArrayList<Student>();
		l.add(new Student("Sonu",29,22));
		l.add(new Student("Dipika",26,24));
		l.add(new Student("Tanusree",25,26));
		
		Collections.sort(l);
		for(Student str:l){
		System.out.println(str);
		}
	}

}

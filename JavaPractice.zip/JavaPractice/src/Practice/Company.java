package Practice;

public class Company {

	String designation = "Automation Engineer";
	String  compname = "CGI";
	
	void work(){
		System.out.println("Testing of Software");
	}

}

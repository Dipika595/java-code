package Practice;

public class Employee extends Company {
	String Name = "Dipika";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee e = new Employee();
		System.out.println("Designation "+e.designation);
		System.out.println("Company "+e.compname);
		System.out.println("Employee name "+e.Name);
		System.out.println("Work done on: ");
		e.work();
		



	}

}
